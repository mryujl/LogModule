package org.tangdao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcarefulApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(SpringcarefulApplication.class, args);
	}

}
