/**
 *
 */
package org.tangdao.modules.sys.model.vo;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author Ryan Ru(ruyangit@gmail.com)
 */
@Getter
@Setter
public class EmpPost {

	private String empCode;
	
	private String postCode;
}
